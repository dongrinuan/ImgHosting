<footer class="site-footer">
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-info">
                    <p>本站提供免费的图片上传服务，支持各种格式的图片链接。</p>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p class="copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?> - 保留所有权利</p>
                <!-- 删除社交媒体联系方式 -->
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>
